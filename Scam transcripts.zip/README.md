# 🔊 Scam Call Detection System

A machine learning system to detect scam calls by transcribing audio and classifying them using TF-IDF and Linear SVM.

## 📁 Project Structure

```
project/
├── audio_files/
│   ├── real/          # Place real audio files here
│   └── scam/          # Place scam audio files here
├── Real transcripts/  # Generated real transcripts
├── Scam transcripts/  # Generated scam transcripts
├── 1_generate_transcripts.py
├── 2_create_dataframe.py
├── 3_train_model.py
├── 4_predict.py
├── requirements.txt
└── README.md
```

## 🚀 Setup Instructions

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

**Note:** If you're on Windows and encounter issues with PyTorch, install it separately:
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### 2. Prepare Your Data

Create the following folder structure:
```
audio_files/
├── real/    # Add your real/legitimate call recordings
└── scam/    # Add your scam call recordings
```

Supported audio formats: `.mp3`, `.wav`, `.m4a`, `.flac`, `.ogg`

## 📝 Usage

### Step 1: Generate Transcripts

Convert audio files to text transcripts:

```bash
python 1_generate_transcripts.py
```

This will:
- Load the Whisper model
- Transcribe all audio files from `audio_files/real/` and `audio_files/scam/`
- Save transcripts to `Real transcripts/` and `Scam transcripts/`

### Step 2: Create Dataset

Combine transcripts into a labeled dataset:

```bash
python 2_create_dataframe.py
```

This will:
- Read all transcripts
- Label them (0 = Real, 1 = Scam)
- Create a CSV file: `transcripts_dataset.csv`

### Step 3: Train the Model

Train the scam detection model:

```bash
python 3_train_model.py
```

This will:
- Load the dataset
- Split into training/testing sets (80/20)
- Train a TF-IDF + Linear SVM model
- Display performance metrics
- Save the trained model and vectorizer

Output files:
- `scam_detector_model.pkl`
- `tfidf_vectorizer.pkl`

### Step 4: Make Predictions

#### Predict from Audio File

```bash
python 4_predict.py 
```

Then choose:
1. Predict from audio file
2. Predict from text (paste or type text directly)

## 🎯 Model Performance

After training, you'll see metrics like:
- **Accuracy**: Overall correctness
- **Precision**: How many predicted scams are actually scams
- **Recall**: How many actual scams were detected
- **F1-Score**: Harmonic mean of precision and recall

## 🔧 Configuration

### Whisper Model Size

In `1_generate_transcripts.py`, you can change the model size:

```python
MODEL_SIZE = "base"  # Options: 'tiny', 'base', 'small', 'medium', 'large'
```

- `tiny`: Fastest, less accurate
- `base`: Good balance (recommended)
- `small`: Better accuracy
- `medium`: High accuracy, slower
- `large`: Best accuracy, slowest

### Train-Test Split

In `3_train_model.py`, adjust the split ratio:

```python
TEST_SIZE = 0.2  # 20% for testing, 80% for training
```

## 📊 Example Output

### Training Output
```
Model Performance Metrics
==================================================
Accuracy:  0.9250
Precision: 0.9100
Recall:    0.9350
F1-Score:  0.9223
```

### Prediction Output
```
Transcribed Text:
==================================================
Hello, this is the IRS calling about your tax refund...

PREDICTION RESULT
==================================================
🚨 This audio is likely a SCAM
Confidence Score: 2.3456
```

## ⚠️ Important Notes

1. **Data Quality**: The model's performance depends on the quality and quantity of your training data
2. **Balanced Dataset**: Try to have roughly equal numbers of real and scam samples
3. **First Run**: The first time you run the scripts, Whisper will download the model (can take a few minutes)
4. **Memory**: Large audio files or the `large` Whisper model require significant RAM

## 🐛 Troubleshooting

### "Model files not found" Error
Run `3_train_model.py` before `4_predict.py`

### Whisper Installation Issues
Try:
```bash
pip install git+https://github.com/openai/whisper.git
```

### Audio File Not Found
Ensure your audio file path is correct and the file exists

## 📄 License

This project uses OpenAI's Whisper model. Check their license for usage terms.
#   S c a m - C a l l - D e t e c t o r  
 